// DlgProxy.h : header file
//

#if !defined(AFX_DLGPROXY_H__1B0A546C_C749_4CF9_8952_B3B1797FB0CB__INCLUDED_)
#define AFX_DLGPROXY_H__1B0A546C_C749_4CF9_8952_B3B1797FB0CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CXdem3Dlg;

/////////////////////////////////////////////////////////////////////////////
// CXdem3DlgAutoProxy command target

class CXdem3DlgAutoProxy : public CCmdTarget
{
	DECLARE_DYNCREATE(CXdem3DlgAutoProxy)

	CXdem3DlgAutoProxy();           // protected constructor used by dynamic creation

// Attributes
public:
	CXdem3Dlg* m_pDialog;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXdem3DlgAutoProxy)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CXdem3DlgAutoProxy();

	// Generated message map functions
	//{{AFX_MSG(CXdem3DlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CXdem3DlgAutoProxy)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CXdem3DlgAutoProxy)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPROXY_H__1B0A546C_C749_4CF9_8952_B3B1797FB0CB__INCLUDED_)
