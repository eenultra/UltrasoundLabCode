// xdem3.h : main header file for the XDEM3 application
//

#if !defined(AFX_XDEM3_H__4560BCFF_0052_4ED8_BB4A_11A0E6388778__INCLUDED_)
#define AFX_XDEM3_H__4560BCFF_0052_4ED8_BB4A_11A0E6388778__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CXdem3App:
// See xdem3.cpp for the implementation of this class
//

class CXdem3App : public CWinApp
{
public:
	CXdem3App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXdem3App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CXdem3App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XDEM3_H__4560BCFF_0052_4ED8_BB4A_11A0E6388778__INCLUDED_)
