// xdem3Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "xdem3.h"
#include "xdem3Dlg.h"
#include "DlgProxy.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXdem3Dlg dialog

IMPLEMENT_DYNAMIC(CXdem3Dlg, CDialog);

CXdem3Dlg::CXdem3Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CXdem3Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CXdem3Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pAutoProxy = NULL;
}

CXdem3Dlg::~CXdem3Dlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
	if (m_pAutoProxy != NULL)
		m_pAutoProxy->m_pDialog = NULL;
}

void CXdem3Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CXdem3Dlg)
	DDX_Control(pDX, IDC_ROBXCTRL1, m_robx);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CXdem3Dlg, CDialog)
	//{{AFX_MSG_MAP(CXdem3Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUT_RUN, OnButRun)
	ON_BN_CLICKED(IDC_BUT_STEP, OnButStep)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CXdem3Dlg message handlers

BOOL CXdem3Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	if(!m_robx.OpenComm(1, 19200))
		AfxMessageBox("Opening Communication, " + m_robx.GetCommErrorString());
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CXdem3Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CXdem3Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CXdem3Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Automation servers should not exit when a user closes the UI
//  if a controller still holds on to one of its objects.  These
//  message handlers make sure that if the proxy is still in use,
//  then the UI is hidden but the dialog remains around if it
//  is dismissed.

void CXdem3Dlg::OnClose() 
{
	if (CanExit())
		CDialog::OnClose();
}

void CXdem3Dlg::OnCancel() 
{
	if (CanExit())
		CDialog::OnCancel();
}

BOOL CXdem3Dlg::CanExit()
{
	// If the proxy object is still around, then the automation
	//  controller is still holding on to this application.  Leave
	//  the dialog around, but hide its UI.
	if (m_pAutoProxy != NULL)
	{
		ShowWindow(SW_HIDE);
		return FALSE;
	}

	m_robx.CloseComm();	

	return TRUE;
}

int sstep = 1;

int CXdem3Dlg::Command_wait(CString command, time_t maxtim){
	if(sstep)
		AfxMessageBox("Ready to send " + command);
	if(!m_robx.SendString(command + "\r")){
		AfxMessageBox("Send string " + m_robx.GetCommErrorString());// problem sending string
		return 0;
	}
	time_t tim = time(0);
	int stat;
	while(1){
		Sleep(100);
		stat = m_robx.GetStatus();
		if(stat)
			break;
		if((time(0) - tim) > maxtim){
			AfxMessageBox(command + " Timed out");
			return 0;
		}
	}
	switch(stat){
	case -1:
		AfxMessageBox(m_robx.GetCommErrorString());// comm problem
		return 0;
		break;
	case 1:
		AfxMessageBox(m_robx.GetResponse());// not OK
		return 0;
		break;
	case 2:
		return 1;	// OK
		break;
	}
	return 0;
}

void CXdem3Dlg::sequence(){
	if(!Command_wait("", 1))
		return;
	if(!Command_wait("TELL WAIST 1000 MOVE", 2))
		return;
	if(!Command_wait("HOME", 1))
		return;
}

void CXdem3Dlg::OnButRun() 
{
	sstep = 0;
	sequence();
}

void CXdem3Dlg::OnButStep() 
{
	sstep = 1;
	sequence();
}
