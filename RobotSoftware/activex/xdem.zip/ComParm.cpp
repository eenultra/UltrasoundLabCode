// ComParm.cpp : implementation file
//

#include "stdafx.h"
#include "xdem.h"
#include "ComParm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComParm dialog


CComParm::CComParm(CWnd* pParent /*=NULL*/)
	: CDialog(CComParm::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComParm)
	m_baud = 0;
	m_port = 0;
	//}}AFX_DATA_INIT
}


void CComParm::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComParm)
	DDX_Text(pDX, IDC_ED_BAUD, m_baud);
	DDV_MinMaxInt(pDX, m_baud, 0, 1000000);
	DDX_Text(pDX, IDC_ED_PORT, m_port);
	DDV_MinMaxInt(pDX, m_port, 0, 1000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CComParm, CDialog)
	//{{AFX_MSG_MAP(CComParm)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComParm message handlers
