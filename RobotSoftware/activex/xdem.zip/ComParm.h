#if !defined(AFX_COMPARM_H__AB326AB1_9897_11D6_9ADA_BA91F205052D__INCLUDED_)
#define AFX_COMPARM_H__AB326AB1_9897_11D6_9ADA_BA91F205052D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ComParm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CComParm dialog

class CComParm : public CDialog
{
// Construction
public:
	CComParm(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CComParm)
	enum { IDD = IDD_COMM_PARM };
	int		m_baud;
	int		m_port;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CComParm)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CComParm)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMPARM_H__AB326AB1_9897_11D6_9ADA_BA91F205052D__INCLUDED_)
