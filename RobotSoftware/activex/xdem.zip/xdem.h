// xdem.h : main header file for the XDEM application
//

#if !defined(AFX_XDEM_H__AB326AA5_9897_11D6_9ADA_BA91F205052D__INCLUDED_)
#define AFX_XDEM_H__AB326AA5_9897_11D6_9ADA_BA91F205052D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CXdemApp:
// See xdem.cpp for the implementation of this class
//

class CXdemApp : public CWinApp
{
public:
	CXdemApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXdemApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CXdemApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XDEM_H__AB326AA5_9897_11D6_9ADA_BA91F205052D__INCLUDED_)
